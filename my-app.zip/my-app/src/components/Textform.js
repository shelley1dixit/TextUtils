import React,{useState} from 'react'

export default function Textform(props) {
    const handleUpClick= ()=>{
        const working= text.toUpperCase();
        setText(working);
        props.showAlert("Text is converted to uppercase!","success");
    }

    const handleLoClick= ()=>{
        const lower=text.toLowerCase();
        setText(lower);
        props.showAlert("Text is converted to lowercase!","success");
    }

    const handleClearText=()=>{
            setText("");
            props.showAlert("Text is cleared!","success");
            }    

    const copyText=()=>{
            var text=document.getElementById("myBox");
            text.select();
            navigator.clipboard.writeText(text.value);
            document.getSelection().removeAllRanges();
            props.showAlert("Text is copied!","success");
            } 

    const removeSpace=()=>{
            let newText= text.split(/[ ]+/);
            setText(newText.join(" "));
            props.showAlert("Spaces are removed successfully!","success");
            }    
            
    const handleOnChange= (event)=>{
        setText(event.target.value);
    }
    const [text, setText]= useState("");
    
  return (   
    <>
    <div style={{color:props.mode==="dark"?"white":"black"}}>
        <h1 className="container my-3">{props.heading}</h1>
        <div className="container my-3" >
        <textarea className="form-control" style={{backgroundColor: props.mode==='light'?'white':'#042743', color:props.mode==="dark"?"white":"black"}} id="myBox" value={text} onChange={handleOnChange} rows="5"></textarea>
        </div>
        <div className="container my-3">
        <button disabled={text.length===0} className="btn btn-primary mx-1 my-1" onClick={handleUpClick} >Convert to uppercase</button>
        <button disabled={text.length===0} className="btn btn-primary mx-1 my-1" onClick={handleLoClick} >Convert to lowercase</button>
        <button disabled={text.length===0} className="btn btn-primary mx-1 my-1" onClick={handleClearText}>Clear text</button>
        <button disabled={text.length===0} className="btn btn-primary mx-1 my-1" onClick={copyText}>Copy Text</button>
        <button disabled={text.length===0} className="btn btn-primary mx-1 my-1" onClick={removeSpace}>Remove Extra Spaces</button>
        </div>
    </div>
    <div className="container my-3" style={{color:props.mode==="dark"?"white":"black"}}>
        <h4>Your text summary</h4>
        <p>words: {text.split(/\s+/).filter((elements)=>{return elements.length!==0;}).length} and length: {text.length}</p>
        <p>total time to read the text: {0.008 * text.split(/\s+/).filter((elements)=>{return elements.length!==0;}).length}</p>
        <h4>Preview</h4>
        <p>{text.length>0?text:"Nothing to preview here"}</p>
    </div>
    </>
  )
}

